package br.edu.unijui;

import br.edu.unijui.xml.XMLHandler;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import static java.util.UUID.fromString;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XMLMessageManager {
    
    public enum priority{};
    
    public static void store(String filename, List<Message> messageList) {
        
        //Criação do documento
        Document doc = XMLHandler.newDocument();
        
        //Criação do Nó Raiz
        Element root = doc.createElement("Messages");
        doc.appendChild(root);
        
        for(int i=0; i<messageList.size(); i++){
            
            //Pega a Lista
            Message m = messageList.get(i);
            
            //Cria o Atributo Message como root
            Element xmlMsg = doc.createElement("Message");
            root.appendChild(xmlMsg);
            xmlMsg.setAttribute("order", Integer.toString(i+1));
            
            //Adiciona os outros atributos dentro de Message(root)
            Element id = doc.createElement("Id");
            id.setTextContent(m.getId().toString());
            xmlMsg.appendChild(id);
            
            Element p = doc.createElement("Priority");
            p.setTextContent(m.getPriority().name());
            xmlMsg.appendChild(p);
            
            Element cd = doc.createElement("Creation-Date");
            cd.setTextContent(m.getCreationDate().toString());
            xmlMsg.appendChild(cd);
            
            Element ed = doc.createElement("Expiration-Date");
            ed.setTextContent(m.getExpirationDate().toString());
            xmlMsg.appendChild(ed);
            
            Element c = doc.createElement("Content");
            c.setTextContent(m.getContent().toString());
            xmlMsg.appendChild(c);
        }
      
        //Persiste a gravação do XML
        XMLHandler.writeXmlFile(doc, filename);
    }
    
   
    public static List<Message> recover( String filename, int numberOfMessages ) throws Exception{
        
        //Cria a lista
        List<Message> recoveredMessages = new ArrayList<Message>();
        
        //Cria o Document
        Document doc = XMLHandler.readXmlFile(filename);
        
        //Loop para inserir as mensagens na lista
        for(int i = 0; i<numberOfMessages; i++){
            int order = i + 1;
            String stmt;
            
            //Recupera os valores dos atributos
            stmt = "//Message[@order='" + order + "']/Id";
            String id = execute(stmt, doc);
            
            stmt = "//Message[@order='" + order + "']/Priority";
            String p = execute(stmt, doc);
            
            stmt = "//Message[@order='" + order + "']/Creation-Date";
            String cd = execute(stmt, doc);
            
            stmt = "//Message[@order='" + order + "']/Expiration-Date";
            String ed = execute(stmt, doc);
            
            stmt = "//Message[@order='" + order + "']/Content";
            String c = execute(stmt, doc);
                    
            //Cria o objeto Mensagem e adiciona os valores dos atributos
            Message msg = new Message();
            msg.setID(fromString(id));
            msg.setPriority(Message.Priority.valueOf(p));
            msg.setCreationDate(toDate(cd));
            msg.setExpirationDate(toDate(ed));
            msg.setContent(c);
            
            //Adiciona as mensagens na lista
            recoveredMessages.add(msg);
        }
        
        return recoveredMessages;
    }
    
    
    public static void printMessages(List<Message> messageList, Message.Priority priority) {

        boolean foundMessage = false;

        for (Message msg : messageList) {
            if (msg.getPriority().equals(priority)) {
                System.out.printf("%s -- %s -- %s -- %s -- %s \n", msg.getId().toString(),
                        msg.getPriority().name(),
                        msg.getCreationDate(),
                        msg.getExpirationDate(),
                        msg.getContent());
                foundMessage = true;
            }
        }

        if (!foundMessage) {
            System.out.println("Não há mensagens com essa prioridade!");
        }

    }
    
    //Executa as chamadas ao XML
    public static String execute(String expression, Document doc) throws Exception {
        XPath xpath = XPathFactory.newInstance().newXPath();
        XPathExpression expr = xpath.compile(expression);
        return (String) expr.evaluate(doc, XPathConstants.STRING);
    }
    
    //Transforma String em Date
    public static Date toDate (String str) throws ParseException {
        final String dateStr = str;
        final DateFormat df = new SimpleDateFormat("EEE MMM d HH:mm:ss zzz yyyy", Locale.ENGLISH);
        final Date date = df.parse(dateStr);
        return date;
    }

}
