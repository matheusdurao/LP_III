package br.edu.unijui.main;

import br.edu.unijui.Message;
import br.edu.unijui.MessageFactory;
import br.edu.unijui.XMLMessageManager;
import java.util.List;

/**
 * Exercício Message Builder XML
 *
 * @author Professor Rafael Zancan Frantz 
 */
public class Start {

    private static final int NUMBER_OF_MESSAGES = 20;

    public static void main(String[] args) throws Exception{

        // Cria uma lista de mensagens aleatórias, com a quantidade de mensagens de acordo com número informado.
        List<Message> generatedMessages = MessageFactory.buildMessages(NUMBER_OF_MESSAGES);

        String filename = "messages.xml";
        
        // Armazena a lista de mensagens em arquivo XML
        XMLMessageManager.store(filename, generatedMessages);
        
        
        // Recupera as mensagens do arquivo XML
        List<Message> recoveredMessages = XMLMessageManager.recover(filename, NUMBER_OF_MESSAGES);

        
        // Imprime na tela as mensagens recuperadas do arquivo XML
        XMLMessageManager.printMessages(recoveredMessages, Message.Priority.LOW);
        

    }

}
