package br.edu.unijui;

import java.util.*;

public class Message {

    // Atributos
    private UUID id;
    private Date creationDate;
    private Priority priority;
    private Date expirationDate;
    private String content;

    
    public enum Priority {
        LOWEST,LOW,NORMAL,HIGH,HIGHEST;

        static Priority valueOf(Priority priority) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }


    // Construtor
    public Message() {
        this( UUID.randomUUID(), new Date() );        
    }
    
    public Message( UUID identifier, Date creationDate ) {
        this.id = identifier;
        this.creationDate = creationDate;
    }
        
    // Operações
    
    public UUID getId() {
        return id;
    }
    
    public void setID(UUID id) {
        this.id = id;
    }
    
    public Priority getPriority() {
        return priority;
    }
    
    public void setPriority( Priority priority ) {
        this.priority = priority;
    }   
    
    public void setContent( String content ) {
        this.content = content;
    }
    
    public String getContent() {
        return content;
    }
    
    public Date getCreationDate() {
        return creationDate;
    }
    
    public void setCreationDate( Date date ) {
        expirationDate = date;
    }
    
    public Date getExpirationDate() {
        return expirationDate;
    }
    
    public void setExpirationDate( Date date ) {
        expirationDate = date;
    }
    
}

